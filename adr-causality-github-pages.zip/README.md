# ADR Causality Assessment – GitHub Pages

This is a simple HTML/CSS/JavaScript internship project for demonstrating adverse drug reaction causality assessment.

## Files

- `index.html` – complete website (HTML, CSS and JavaScript in one file)

## Run locally

Open `index.html` in a web browser.

## GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.

Your website will then be available through the GitHub Pages URL shown by GitHub.

## Example case

45-year-old female, Amoxicillin, skin rash, onset after 3 days, rash resolves after discontinuation, no alternative cause identified, rechallenge not performed → Probable.
